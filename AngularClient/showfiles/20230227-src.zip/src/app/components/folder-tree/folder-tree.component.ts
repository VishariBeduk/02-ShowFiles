import { Component } from '@angular/core';

import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';

import { FilesService } from '../../services/files.service';

@Component({
  selector: 'app-folder-tree',
  templateUrl: './folder-tree.component.html',
  styleUrls: ['./folder-tree.component.css']
})
export class FolderTreeComponent {
  homeFolder: string = '<unknown>';
  folderPaths: string[] = [];

  constructor(private fileService: FilesService) {
    this.dataSource.data = TREE_DATA;
  }

  retrieveHomeFolder(): void {
    this.fileService.getHomeFolder()
      .subscribe((root: string) => { this.homeFolder = root; });
  }

  retrieveFolderList(): void {
    this.fileService.getFiles(this.homeFolder)
      .subscribe((r: string[]) => { this.folderPaths = r; });
  }

  private _transformer = (node: FolderNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
    };
  };

  treeControl = new FlatTreeControl<FolderTreeFlatNode>(
    node => node.level,
    node => node.expandable,
  );

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    node => node.level,
    node => node.expandable,
    node => node.children,
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  hasChild = (_: number, node: FolderTreeFlatNode) => node.expandable;
}



/**
 * Food data with nested structure.
 * Each node has a name and an optional list of children.
 */
interface FolderNode {
  name: string;
  children?: FolderNode[];
}

const TREE_DATA: FolderNode[] = [
  {
    name: 'Fruit',
    children: [{name: 'Apple'}, {name: 'Banana'}, {name: 'Fruit loops'}],
  },
  {
    name: 'Vegetables',
    children: [
      {
        name: 'Green',
        children: [{name: 'Broccoli'}, {name: 'Brussels sprouts'}],
      },
      {
        name: 'Orange',
        children: [{name: 'Pumpkins'}, {name: 'Carrots'}],
      },
    ],
  },
];

/** Flat node with expandable and level information */
interface FolderTreeFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}
